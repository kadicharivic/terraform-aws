import json
from botocore.vendored import requests
import boto3
import base64



def lambda_handler(event, context):
    endpoint = 'https://api.punkapi.com/v2/beers/random'
    payload = requests.get(endpoint).json()
    
    payload_str = json.dumps(payload)
    
    # payload_b64 = base64.b64encode(payload)
    payload_b64 = bytes(payload_str, 'utf-8')
    
    client = boto3.client('kinesis')
    
    response = client.put_record(
        StreamName='terraform-kinesis-stream',
        Data=payload_b64,
        PartitionKey=str(payload[0]['id']))
    
    return { 
        'statusCode': 200,
        'body': response}
        
