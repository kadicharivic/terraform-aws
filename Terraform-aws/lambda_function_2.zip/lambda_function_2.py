from __future__ import print_function
import base64
import json
import csv
import boto3
import botocore
import os
from botocore.exceptions import ClientError


print('Loading function')


def lambda_handler(event, context):
   
    for record in event['records']:
        
        payload = base64.b64decode(record['data'])
        
        str_payload = payload.decode("UTF-8")
        
        list_payload = json.loads(str_payload)
        
        result = {
            'id': list_payload[0]['id'],
            'name': list_payload[0]['name'],
            'abv': list_payload[0]['abv'],
            'ibu': list_payload[0]['ibu'],
            'target_fg': list_payload[0]['target_fg'],
            'target_og': list_payload[0]['target_og'],
            'ebc': list_payload[0]['ebc'],
            'srm': list_payload[0]['srm'],
            'ph': list_payload[0]['ph']
        }

    BUCKET_NAME = 'cleaned-desafio-picpay'
    file_name = 'success/data_clean.csv'
    local_file_name = '/tmp/data.csv'
    s3 = boto3.resource('s3')
    bucket = s3.Bucket(BUCKET_NAME)
    lists = list(result.keys())
    
    try:
        bucket.download_file(file_name,local_file_name)
        
        with open(local_file_name,'r') as infile:
            reader = list(csv.DictReader(infile, fieldnames=lists))
            
            reader = reader[::-1] # the date is ascending order in file
    
            reader.insert(-1,result)

            print(len(reader))

            writer_function(local_file_name,lists, reader)
            
    except ClientError:
        writer_function(local_file_name,lists, result)
                    
    bucket.upload_file(local_file_name, file_name)
    
    
    print('Successfully processed {} records.'.format(len(event['records'])))
    return {'statusCode': 200}
    

def writer_function(local_file_name,lists, reader):

       with open(local_file_name, 'w', newline='') as outfile:
            writer = csv.DictWriter(outfile, fieldnames=lists)

            if type(reader)==dict:
                writer.writerow(reader)

            else:      
                for line in reversed(reader): # reverse order
                    writer.writerow(line)


            